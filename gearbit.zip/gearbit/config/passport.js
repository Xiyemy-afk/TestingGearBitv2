const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

// ====================================================================
// "Database" sementara di memori. Untuk produksi, ganti dengan
// database sungguhan (MongoDB, PostgreSQL, dll).
// ====================================================================
const users = new Map(); // key: google id, value: user object

passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: process.env.GOOGLE_CALLBACK_URL
  },
  function(accessToken, refreshToken, profile, done) {
    // Cari atau buat user baru berdasarkan Google ID
    let user = users.get(profile.id);

    if (!user) {
      user = {
        id: profile.id,
        name: profile.displayName,
        email: profile.emails && profile.emails[0] ? profile.emails[0].value : null,
        avatar: profile.photos && profile.photos[0] ? profile.photos[0].value : null,
        isSeller: false,
        sellerVerification: null // diisi saat submit form verifikasi
      };
      users.set(profile.id, user);
    }

    return done(null, user);
  }
));

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  const user = users.get(id);
  done(null, user || null);
});

module.exports = { passport, users };
