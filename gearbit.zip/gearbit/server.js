require('dotenv').config();

const express = require('express');
const session = require('express-session');
const path = require('path');
const axios = require('axios');
const multer = require('multer');
const { passport, users } = require('./config/passport');

const app = express();
const PORT = process.env.PORT || 3000;

// ====================================================================
// View engine & static files
// ====================================================================
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ====================================================================
// Session & Passport
// ====================================================================
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev_secret_jangan_dipakai_di_produksi',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 } // 1 hari
}));
app.use(passport.initialize());
app.use(passport.session());

// ====================================================================
// File upload (untuk dokumen KYC) — disimpan lokal di /uploads
// ====================================================================
const upload = multer({
  dest: path.join(__dirname, 'uploads'),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

// ====================================================================
// Middleware bantuan: cek login
// ====================================================================
function ensureAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.redirect('/');
}

// Hitung umur dari tanggal lahir
function calculateAge(dobString) {
  const dob = new Date(dobString);
  if (isNaN(dob.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return age;
}

// ====================================================================
// Routes: Halaman utama
// ====================================================================
app.get('/', (req, res) => {
  res.render('index', {
    user: req.user || null,
    recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY
  });
});

// ====================================================================
// Routes: Google OAuth
// ====================================================================
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/' }),
  (req, res) => {
    res.redirect('/');
  }
);

app.get('/logout', (req, res) => {
  req.logout(() => {
    res.redirect('/');
  });
});

// ====================================================================
// Routes: Form verifikasi seller (KYC + captcha)
// ====================================================================
app.get('/verify', ensureAuth, (req, res) => {
  res.render('verify', {
    user: req.user,
    recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY,
    error: null
  });
});

app.post('/verify', ensureAuth, upload.fields([
  { name: 'idDocument', maxCount: 1 },
  { name: 'selfieDocument', maxCount: 1 }
]), async (req, res) => {
  const { fullname, dob, phone, idtype, guardianPhone, 'g-recaptcha-response': captchaToken } = req.body;

  // ---- 1. Validasi captcha ke Google ----
  if (!captchaToken) {
    return res.render('verify', {
      user: req.user,
      recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY,
      error: 'Mohon selesaikan captcha terlebih dahulu.'
    });
  }

  try {
    const verifyRes = await axios.post('https://www.google.com/recaptcha/api/siteverify', null, {
      params: {
        secret: process.env.RECAPTCHA_SECRET_KEY,
        response: captchaToken
      }
    });

    if (!verifyRes.data.success) {
      return res.render('verify', {
        user: req.user,
        recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY,
        error: 'Verifikasi captcha gagal. Coba lagi.'
      });
    }
  } catch (err) {
    console.error('reCAPTCHA error:', err.message);
    return res.render('verify', {
      user: req.user,
      recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY,
      error: 'Terjadi kesalahan saat memverifikasi captcha. Coba lagi.'
    });
  }

  // ---- 2. Validasi usia minimum 15 tahun ----
  const age = calculateAge(dob);
  if (age === null) {
    return res.render('verify', {
      user: req.user,
      recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY,
      error: 'Tanggal lahir tidak valid.'
    });
  }
  if (age < 15) {
    return res.render('verify', {
      user: req.user,
      recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY,
      error: 'Pendaftaran seller hanya untuk usia 15 tahun ke atas.'
    });
  }
  if (age < 18 && !guardianPhone) {
    return res.render('verify', {
      user: req.user,
      recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY,
      error: 'Untuk usia 15-17 tahun, kontak orang tua/wali wajib diisi.'
    });
  }

  // ---- 3. Validasi dokumen ----
  if (!req.files || !req.files.idDocument || !req.files.selfieDocument) {
    return res.render('verify', {
      user: req.user,
      recaptchaSiteKey: process.env.RECAPTCHA_SITE_KEY,
      error: 'Mohon upload dokumen identitas dan foto selfie dengan dokumen.'
    });
  }

  // ---- 4. Simpan data verifikasi (sementara di memori) ----
  const user = users.get(req.user.id);
  user.sellerVerification = {
    fullname,
    dob,
    age,
    phone,
    idtype,
    guardianPhone: guardianPhone || null,
    idDocumentPath: req.files.idDocument[0].path,
    selfieDocumentPath: req.files.selfieDocument[0].path,
    status: 'pending', // pending -> approved/rejected (direview admin)
    submittedAt: new Date()
  };
  user.isSeller = false; // baru jadi seller kalau status diubah jadi 'approved' oleh admin

  res.render('verify-success', { user });
});

// ====================================================================
app.listen(PORT, () => {
  console.log(`Gearbit jalan di http://localhost:${PORT}`);
});
