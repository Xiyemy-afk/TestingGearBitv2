# Gearbit — Marketplace Item/Skin & Jasa Joki Game

Marketplace dengan login Google (OAuth) dan verifikasi seller (KYC + reCAPTCHA),
wajib usia minimal 15 tahun.

## 1. Install

Pastikan Node.js (v18+) sudah terinstall, lalu di folder project jalankan:

```bash
npm install
```

## 2. Setup file .env

Salin `.env.example` jadi `.env`:

```bash
cp .env.example .env
```

Lalu isi nilai-nilai di dalamnya. Berikut cara dapatkan tiap kredensial:

### a. SESSION_SECRET

String acak untuk enkripsi session. Generate dengan:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copy hasilnya ke `SESSION_SECRET`.

### b. Google OAuth (GOOGLE_CLIENT_ID & GOOGLE_CLIENT_SECRET)

1. Buka https://console.cloud.google.com/
2. Buat project baru (atau pilih project yang sudah ada).
3. Di sidebar, buka **APIs & Services > OAuth consent screen**.
   - Pilih **External**, isi nama app (misal "Gearbit"), email kontak, lalu simpan.
   - Status app boleh tetap "Testing" untuk pengembangan lokal — tambahkan emailmu
     sendiri sebagai **Test user** di tab Audience/Test users.
4. Buka **APIs & Services > Credentials**.
5. Klik **Create Credentials > OAuth client ID**.
   - Application type: **Web application**
   - Authorized redirect URIs, tambahkan:
     ```
     http://localhost:3000/auth/google/callback
     ```
6. Setelah dibuat, copy **Client ID** dan **Client Secret** ke `.env`:
   ```
   GOOGLE_CLIENT_ID=xxxxxxxx.apps.googleusercontent.com
   GOOGLE_CLIENT_SECRET=xxxxxxxx
   ```

### c. Google reCAPTCHA (RECAPTCHA_SITE_KEY & RECAPTCHA_SECRET_KEY)

1. Buka https://www.google.com/recaptcha/admin/create
2. Isi label (misal "Gearbit Local").
3. Pilih tipe **reCAPTCHA v2 "I'm not a robot" Checkbox**.
4. Di kolom domains, tambahkan:
   ```
   localhost
   ```
5. Submit. Kamu akan mendapat **Site Key** dan **Secret Key** — copy ke `.env`:
   ```
   RECAPTCHA_SITE_KEY=xxxxxxxx
   RECAPTCHA_SECRET_KEY=xxxxxxxx
   ```

## 3. Jalankan server

```bash
npm start
```

Buka browser ke **http://localhost:3000**

## 4. Cara pakai

1. Klik **Masuk** / **Jual di Sini** → login pakai akun Google.
2. Setelah login, klik **Jadi Seller** → isi form verifikasi:
   - Nama lengkap, tanggal lahir (otomatis dicek minimal 15 tahun di server),
   - Nomor HP, jenis dokumen,
   - Upload foto KTP/KIA dan foto selfie dengan dokumen,
   - Jika usia 15–17 tahun, wajib isi kontak orang tua/wali,
   - Centang persetujuan dan selesaikan **reCAPTCHA**.
3. Server akan:
   - Memverifikasi token reCAPTCHA ke Google (`/recaptcha/api/siteverify`),
   - Menghitung umur dari tanggal lahir dan menolak jika < 15 tahun,
   - Menyimpan dokumen yang diupload ke folder `uploads/` (lokal),
   - Menyimpan status verifikasi sebagai `pending` (perlu direview admin).

## 5. Catatan untuk produksi

Project ini masih level "belajar/lokal". Sebelum dipakai serius:

- Ganti "database" in-memory (`config/passport.js` — `Map users`) dengan database
  sungguhan (PostgreSQL/MongoDB).
- Simpan file upload ke storage terpisah (S3, dsb), bukan folder lokal.
- Tambahkan halaman admin untuk approve/reject verifikasi seller.
- Pakai HTTPS dan ganti `GOOGLE_CALLBACK_URL` serta domain reCAPTCHA ke domain
  produksi kamu.
- Jangan commit file `.env` ke git (sudah ada `.gitignore` untuk ini).

## Struktur folder

```
gearbit/
├── server.js              # entry point Express
├── config/passport.js     # konfigurasi Google OAuth
├── views/                  # halaman EJS (index, verify, verify-success)
├── public/style.css        # styling
├── uploads/                 # dokumen KYC yang diupload (dibuat otomatis)
├── .env.example
└── package.json
```
